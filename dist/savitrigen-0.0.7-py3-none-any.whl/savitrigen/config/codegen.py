from dataclasses import dataclass

@dataclass
class CodegenConfig(object):
    boilerplate_repo_url:str
