#!/usr/bin/env python3

"""
Tool for generating systems using Savitri software.
Copyright 2022 Protolab LTDA, Brazil
"""

__author__ = 'João Gabriel Santos'
__copyright__ = 'Copyright 2022 Protolab LTDA'
__version__ = '0.0.7'
