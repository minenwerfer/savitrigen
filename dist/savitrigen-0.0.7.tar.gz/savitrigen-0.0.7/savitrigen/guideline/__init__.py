import sys
from .guideline import Guideline

sys.modules[__name__] = Guideline()
